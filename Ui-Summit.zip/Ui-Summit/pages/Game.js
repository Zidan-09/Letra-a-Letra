class GamePage extends HTMLElement {
    connectedCallBack() {
        this.innerHTML = `
            Teste
        `;


    }
}

customElements.define("game-page", GamePage);
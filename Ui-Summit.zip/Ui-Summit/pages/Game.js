class GamePage extends HTMLElement {
    connectedCallBack() {
        this.innerHTML = `
            <player-component></player-component>
            <words-component></words-component>
            <board-component></board-component>
            <inventory-component></inventory-component>
        `;
    }
}

customElements.define("game-page", GamePage);
class HomePage extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <div class="container">
                <img src="public/logo2.png" alt="Logo Letra a Letra" class="logo" />

                <p class="label">Insira seu Nome</p>

                <input
                    type="text"
                    placeholder="ex: Player123..."
                    class="input"
                    id="name"
                />

                <button class="button" id="play">Jogar</button>
            </div>
        `;
    }
}

customElements.define("home-page", HomePage);
class MatchmakingPage extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <div class="matchmaking-container">
                <div id="searching-state">
                    <h1 id="mm-title">Buscando Oponente...</h1>
                    <div id="mm-spinner" class="spinner"></div>
                </div>
                
                <div id="found-state" style="display: none;">
                    <h2>Oponente Encontrado!</h2>
                    <p class="vs-text">
                        <span id="my-name"></span> <strong>VS</strong> <span id="opponent-name"></span>
                    </p>
                    <p>Preparando a partida...</p>
                </div>
            </div>
        `;
    }

    showOpponent(myName, opponentName) {
        document.getElementById("searching-state").style.display = "none";
        document.getElementById("found-state").style.display = "block";
        
        document.getElementById("my-name").innerText = myName;
        document.getElementById("opponent-name").innerText = opponentName;
    }
}

customElements.define("matchmaking-page", MatchmakingPage);
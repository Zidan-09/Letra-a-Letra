let id;

async function register(name) {
    console.log("Iniciando Cadastro...");

    try {
        const res = await fetch("http://localhost:8080/", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: `${name}@gmail.com`,
                password: "12345678"
            })
        });

        console.log(res);

    } catch (err) {
        console.error(err);
    }
}

async function login(name) {
    console.log("Login")
}

export function initHomeLogic() {
    const button = document.getElementById("play");

    button.addEventListener("click", async () => {
        const name = document.getElementById("name");

        const testName = name.value.trim();

        if (testName < 5 || testName > 15) return;

        await register(name);
        await login(name);
    });
}

export function getId() {
    return id;
}
export function initGameLogic() {
    
}
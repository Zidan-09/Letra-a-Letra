import "../components/player.js";
import "../components/words.js";
import "../components/board.js";
import "../components/inventory.js";
import "../pages/Home.js";
import "../pages/Game.js";

let httpUrl = "http://localhost:8080"
let wsUrl = "ws://localhost:8080/ws/game?token="

let id;
let token;

async function register(name) {
    console.log("Iniciando Cadastro...");

    try {
        const res = await fetch(`${httpUrl}/user`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: `${name}@gmail.com`,
                password: "12345678"
            })
        });

        console.log(res);

    } catch (err) {
        console.error(err);
    }
}

async function login(name) {
    console.log("Iniciando Login...");

    try {
        const res = await fetch(`${httpUrl}/user/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: `${name}@gmail.com`,
                password: "12345678"
            })
        });

        console.log(res);

        id = res.data.id;
        token = res.data.token;

    } catch (err) {
        console.error(err);
    }
}

export function navigate(page) {
    const root = document.body;

    if (page == "home") {
        root.innerHTML = '<home-page></home-page>';

    } else {
        root.innerHTML = '<game-page></game-page>';
    }
}

navigate("home");

const play = document.getElementById("play");

play.addEventListener("click", async () => {
    const name = document.getElementById("name");

    const testName = name.value.trim();

    if (testName < 5 || testName > 15) return;

    await register(name);
    await login(name);

    navigate("game");
});


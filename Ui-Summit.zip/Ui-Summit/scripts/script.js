import "../pages/Home.js";
import "../pages/Game.js";
import { initHomeLogic } from "./home.js";
import { initGameLogic } from "./game.js";

export function navigate(page) {
    const root = document.body;

    if (page == "home") {
        root.innerHTML = '<home-page></home-page>';
        initHomeLogic();

    } else {
        root.innerHTML = '<game-page></game-page>';
        initGameLogic();
    }
}

navigate("home");